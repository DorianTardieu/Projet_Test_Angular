export interface Cv {
  id: number;
  name: string;
  email: string;
  phone: string;
  skills: string[];
  image: string;
}
