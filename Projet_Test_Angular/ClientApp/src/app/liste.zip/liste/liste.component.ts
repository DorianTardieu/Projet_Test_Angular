import { Component, OnInit } from '@angular/core';
import { Cv } from './cv.model';
@Component({
  selector: 'app-liste',
  templateUrl: './liste.component.html',
  styleUrls: ['./liste.component.css']
})
export class ListeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  cvs: Cv[] = [
    { id: 1, name: 'John Doe', email: 'john@example.com', phone: '0123456789', skills: ['JavaScript', 'Angular'], image: 'https://th.bing.com/th/id/OIP.jElMJdubx_sAjG5ja5RwzAHaHa?rs=1&pid=ImgDetMain' },
    { id: 2, name: 'Paul Smith', email: 'Paul@example.com', phone: '0123456789', skills: ['Python', 'Angular'], image: 'https://media.licdn.com/dms/image/C4D03AQGjQkvlktH_ng/profile-displayphoto-shrink_800_800/0/1585685479062?e=2147483647&v=beta&t=BQcSXY7yQdNoF6_50FMm9h3HawxMLM8b-qtan5d5SUo' },
    { id: 3, name: 'Jane Bernard', email: 'jane@example.com', phone: '0123456789', skills: ['Python', 'Django'], image:'https://th.bing.com/th/id/OIP.zQvSuKlt4RyFQG7HHSribwAAAA?w=474&h=474&rs=1&pid=ImgDetMain' }
  ];
  selectedCv: Cv | null = null;

  showDetails(cv: Cv) {
    this.selectedCv = cv;

  }

}
